<div id='footer'>
	<h1>&copy;<?php echo date('Y')?> Pieterjan van Dijk <span id='spooter'></span><p id='spanid'><?php echo date("d/m/Y"); ?></p></h1>
</div>