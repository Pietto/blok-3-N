<nav class="navbar navbar-inverse">
	<div class="container-fluid">
	    <div class="navbar-header">
	    	<a class="navbar-brand" href="#">Templating</a>
	    </div>
	    <ul class="nav navbar-nav">
	    	<li id='Home'><a href="index.php">Home</a></li>
	    	<li id='Over mij'><a href="overmij.php">Over mij</a></li>
	    	<li id='Photo gallery'><a href="photo-gallery.php">photo gallery</a></li>
	    	<li id='Contact'><a href="contact.php">Contact</a></li>
	    </ul>
	    <img src='images/author.jpg' alt='author' id='profilepic'>
	</div>
</nav>