<!-- <?php
    // $servername = "localhost";
    // $username = "root";
    // $password = "mysql";
    // $dbname = 'Planningstool';

    // try {
    //     $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    //     // set the PDO error mode to exception
    //     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //     // sql to create table
    //     $sql = "CREATE TABLE plannedgames (
    //         id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
    //         game VARCHAR(30) NOT NULL,
    //         time VARCHAR(30) NOT NULL,
    //         teacher VARCHAR(50),
    //         players VARCHAR(50)
    //     )";

    //     // use exec() because no results are returned
    //     $conn->exec($sql);
    //     echo '<script>console.log("Database created successfully");</script>';
    //     }
    // catch(PDOException $e)
    //     {
    // echo '<script>console.log("Connection failed: ' . $e->getMessage() . '");</script>';
    //     }

    // $conn = null;
?> -->