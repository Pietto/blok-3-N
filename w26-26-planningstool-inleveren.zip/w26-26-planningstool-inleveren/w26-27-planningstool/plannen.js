function loadURL(){
	window.open("games.php", "_self");
}